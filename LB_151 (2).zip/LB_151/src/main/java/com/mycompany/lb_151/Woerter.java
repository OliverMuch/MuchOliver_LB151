/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lb_151;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author OMC
 */
@Entity
@Table(name = "woerter")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Woerter.findAll", query = "SELECT w FROM Woerter w"),
    @NamedQuery(name = "Woerter.findByIDWoerter", query = "SELECT w FROM Woerter w WHERE w.iDWoerter = :iDWoerter"),
    @NamedQuery(name = "Woerter.findByWort", query = "SELECT w FROM Woerter w WHERE w.wort = :wort")})
public class Woerter implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID_Woerter")
    private Integer iDWoerter;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "wort")
    private String wort;
    @JoinColumn(name = "ID_Kategorie", referencedColumnName = "ID_Kategorie")
    @ManyToOne(optional = false)
    private Kategorie iDKategorie;
    @JoinColumn(name = "ID_Schwierigkeit", referencedColumnName = "ID_Schwierigkeit")
    @ManyToOne(optional = false)
    private Schwierigkeit iDSchwierigkeit;

    public Woerter() {
    }

    public Woerter(Integer iDWoerter) {
        this.iDWoerter = iDWoerter;
    }

    public Woerter(Integer iDWoerter, String wort) {
        this.iDWoerter = iDWoerter;
        this.wort = wort;
    }

    public Integer getIDWoerter() {
        return iDWoerter;
    }

    public void setIDWoerter(Integer iDWoerter) {
        this.iDWoerter = iDWoerter;
    }

    public String getWort() {
        return wort;
    }

    public void setWort(String wort) {
        this.wort = wort;
    }

    public Kategorie getIDKategorie() {
        return iDKategorie;
    }

    public void setIDKategorie(Kategorie iDKategorie) {
        this.iDKategorie = iDKategorie;
    }

    public Schwierigkeit getIDSchwierigkeit() {
        return iDSchwierigkeit;
    }

    public void setIDSchwierigkeit(Schwierigkeit iDSchwierigkeit) {
        this.iDSchwierigkeit = iDSchwierigkeit;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDWoerter != null ? iDWoerter.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Woerter)) {
            return false;
        }
        Woerter other = (Woerter) object;
        if ((this.iDWoerter == null && other.iDWoerter != null) || (this.iDWoerter != null && !this.iDWoerter.equals(other.iDWoerter))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.lb_151.Woerter[ iDWoerter=" + iDWoerter + " ]";
    }
    
}
