/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lb_151;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author OMC
 */
@Entity
@Table(name = "spiel")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Spiel.findAll", query = "SELECT s FROM Spiel s"),
    @NamedQuery(name = "Spiel.findByIDSpiel", query = "SELECT s FROM Spiel s WHERE s.iDSpiel = :iDSpiel"),
    @NamedQuery(name = "Spiel.findByName", query = "SELECT s FROM Spiel s WHERE s.name = :name"),
    @NamedQuery(name = "Spiel.findByGuthaben", query = "SELECT s FROM Spiel s WHERE s.guthaben = :guthaben")})
public class Spiel implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID_Spiel")
    private Integer iDSpiel;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "Name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Column(name = "Guthaben")
    private int guthaben;

    public Spiel() {
    }

    public Spiel(Integer iDSpiel) {
        this.iDSpiel = iDSpiel;
    }

    public Spiel(Integer iDSpiel, String name, int guthaben) {
        this.iDSpiel = iDSpiel;
        this.name = name;
        this.guthaben = guthaben;
    }

    public Integer getIDSpiel() {
        return iDSpiel;
    }

    public void setIDSpiel(Integer iDSpiel) {
        this.iDSpiel = iDSpiel;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGuthaben() {
        return guthaben;
    }

    public void setGuthaben(int guthaben) {
        this.guthaben = guthaben;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDSpiel != null ? iDSpiel.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Spiel)) {
            return false;
        }
        Spiel other = (Spiel) object;
        if ((this.iDSpiel == null && other.iDSpiel != null) || (this.iDSpiel != null && !this.iDSpiel.equals(other.iDSpiel))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.lb_151.Spiel[ iDSpiel=" + iDSpiel + " ]";
    }
    
}
