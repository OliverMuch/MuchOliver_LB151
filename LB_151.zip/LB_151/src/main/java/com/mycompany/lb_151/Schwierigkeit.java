/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lb_151;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author OMC
 */
@Entity
@Table(name = "schwierigkeit")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Schwierigkeit.findAll", query = "SELECT s FROM Schwierigkeit s"),
    @NamedQuery(name = "Schwierigkeit.findByIDSchwierigkeit", query = "SELECT s FROM Schwierigkeit s WHERE s.iDSchwierigkeit = :iDSchwierigkeit"),
    @NamedQuery(name = "Schwierigkeit.findBySchwierigkeitsgrad", query = "SELECT s FROM Schwierigkeit s WHERE s.schwierigkeitsgrad = :schwierigkeitsgrad")})
public class Schwierigkeit implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID_Schwierigkeit")
    private Integer iDSchwierigkeit;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "schwierigkeitsgrad")
    private String schwierigkeitsgrad;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "iDSchwierigkeit")
    private Collection<Woerter> woerterCollection;

    public Schwierigkeit() {
    }

    public Schwierigkeit(Integer iDSchwierigkeit) {
        this.iDSchwierigkeit = iDSchwierigkeit;
    }

    public Schwierigkeit(Integer iDSchwierigkeit, String schwierigkeitsgrad) {
        this.iDSchwierigkeit = iDSchwierigkeit;
        this.schwierigkeitsgrad = schwierigkeitsgrad;
    }

    public Integer getIDSchwierigkeit() {
        return iDSchwierigkeit;
    }

    public void setIDSchwierigkeit(Integer iDSchwierigkeit) {
        this.iDSchwierigkeit = iDSchwierigkeit;
    }

    public String getSchwierigkeitsgrad() {
        return schwierigkeitsgrad;
    }

    public void setSchwierigkeitsgrad(String schwierigkeitsgrad) {
        this.schwierigkeitsgrad = schwierigkeitsgrad;
    }

    @XmlTransient
    public Collection<Woerter> getWoerterCollection() {
        return woerterCollection;
    }

    public void setWoerterCollection(Collection<Woerter> woerterCollection) {
        this.woerterCollection = woerterCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iDSchwierigkeit != null ? iDSchwierigkeit.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Schwierigkeit)) {
            return false;
        }
        Schwierigkeit other = (Schwierigkeit) object;
        if ((this.iDSchwierigkeit == null && other.iDSchwierigkeit != null) || (this.iDSchwierigkeit != null && !this.iDSchwierigkeit.equals(other.iDSchwierigkeit))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.lb_151.Schwierigkeit[ iDSchwierigkeit=" + iDSchwierigkeit + " ]";
    }
    
}
