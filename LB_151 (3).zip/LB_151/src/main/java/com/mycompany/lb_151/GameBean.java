/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.lb_151;

import java.awt.Desktop;
import static java.awt.SystemColor.window;
import java.io.IOException;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;

/**
 *
 * @author OMC
 */
@Named(value = "gameBean")
@SessionScoped
public class GameBean implements Serializable {

    /**
     * Creates a new instance of GameBean
     */
    public GameBean() {

    }

    private String spinResult;
    private int spinValue;

    public int getSpinValue() {
        return spinValue;
    }

    public void setSpinValue(int spinValue) {
        this.spinValue = spinValue;
    }
    private String name;
    private String lösung;
    private char buchstabeEingabe;
    private String emptyLösung = "";
    private int guthaben = 0;
    private int anzLeben = 0;
    private boolean spinDisabled;
    private boolean ratenDisabled;
    private boolean spielenDisabled;
    private String fehlermeldung;
    private String wortEingabe;
    private int anzRunden;

    public int getAnzRunden() {
        return anzRunden;
    }

    public void setAnzRunden(int anzRunden) {
        this.anzRunden = anzRunden;
    }

    public String getWortEingabe() {
        return wortEingabe;
    }

    public void setWortEingabe(String wortEingabe) {
        this.wortEingabe = wortEingabe;
    }

    public String getFehlermeldung() {
        return fehlermeldung;
    }

    public void setFehlermeldung(String fehlermeldung) {
        this.fehlermeldung = fehlermeldung;
    }

    public boolean isSpielenDisabled() {
        return spielenDisabled;
    }

    public void setSpielenDisabled(boolean spielenDisabled) {
        this.spielenDisabled = spielenDisabled;
    }
    private char vokal;
    private char konsonant;

    public char getVokal() {
        return vokal;
    }

    public void setVokal(char vokal) {
        this.vokal = vokal;
    }

    public char getKonsonant() {
        return konsonant;
    }

    public void setKonsonant(char konsonant) {
        this.konsonant = konsonant;
    }

    public boolean isSpinDisabled() {
        return spinDisabled;
    }

    public void setSpinDisabled(boolean spinDisabled) {
        this.spinDisabled = spinDisabled;
    }

    public boolean isRatenDisabled() {
        return ratenDisabled;
    }

    public void setRatenDisabled(boolean ratenDisabled) {
        this.ratenDisabled = ratenDisabled;
    }

    public String getEmptyLösung() {
        return emptyLösung;
    }

    public void setEmptyLösung(String emptyLösung) {
        this.emptyLösung = emptyLösung;
    }

    public char getBuchstabeEingabe() {
        return buchstabeEingabe;
    }

    public void setBuchstabeEingabe(char buchstabeEingabe) {
        this.buchstabeEingabe = buchstabeEingabe;
    }

    public String getLösung() {
        return lösung;
    }

    public void setLösung(String lösung) {
        this.lösung = lösung;
    }

    public String getSpinResult() {
        return spinResult;
    }

    public void setSpinResult(String spinResult) {
        this.spinResult = spinResult;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGuthaben() {
        return guthaben;
    }

    public void setGuthaben(int guthaben) {
        this.guthaben = guthaben;
    }

    public int getAnzLeben() {
        return anzLeben;
    }

    public void setAnzLeben(int anzLeben) {
        this.anzLeben = anzLeben;
    }

    public void beanClick() {
        System.out.println("Name: " + name);
    }

    public String spin() {
        spinDisabled = true;
        ratenDisabled = false;
        anzRunden++;
        Random r = new Random();
        int randomResult = r.nextInt(100) + 1;

        if (randomResult < 7) {
            spinResult = "Bankrott";
            guthaben = 0;
            fehlermeldung = "Verloren :(";
            spinDisabled = true;
            ratenDisabled = true;
            spielenDisabled = false;
        } else {
            spinValue = r.nextInt(2000 - 500) + 500;
            spinResult = String.valueOf(spinValue);
        }

        System.out.println("randomResult");
        return spinResult;
    }

    //Buchstabe raten
    public void raten() {
        ratenDisabled = true;
        spinDisabled = false;
        int index = lösung.indexOf(buchstabeEingabe);

        HashSet<Character> set = new HashSet<Character>();
        List<Integer> duplicates = new ArrayList<Integer>();

        for (int i = 0; i < lösung.length(); i++) {
            char letter = lösung.charAt(i);
            if (set.contains(letter)) {
                duplicates.add(i);
            } else {
                set.add(letter);
            }
        }

        if (index != -1) {
            //Wenn der Buchstabe im Wort vorkommt:
            System.out.println("Der Buchstabe " + buchstabeEingabe + " befindet sich an der Position " + index + " im Lösungswort.");
            if (duplicates.isEmpty()) {
                System.out.println("Keine mehrfach vorkommenden Buchstaben gefunden.");
            } else {
                //Doppelte Buchstaben:
                System.out.println("Die folgenden Buchstaben kommen mehrmals vor:");
                for (int i = 0; i < duplicates.size(); i++) {
                    int indexd = duplicates.get(i);
                    char letter = lösung.charAt(indexd);
                    System.out.println("Buchstabe " + letter + " kommt an den Positionen " + index + " vor.");

                    if (buchstabeEingabe == letter) {
                        emptyLösung = emptyLösung.substring(0, indexd) + letter + emptyLösung.substring(indexd + 1);
                    }
                }
            }

            if (!emptyLösung.contains(String.valueOf(buchstabeEingabe))) {
                guthaben += spinValue;
            }

            emptyLösung = emptyLösung.substring(0, index) + buchstabeEingabe + emptyLösung.substring(index + 1);
            System.out.println(emptyLösung);

        } else {
            //Buchstabe falsch
            System.out.println("Der Buchstabe " + buchstabeEingabe + " kommt nicht im Lösungswort vor.");
            fehlermeldung = "Buchstabe kommt nicht im Wort vor!";

            if (anzLeben == 1) {
                anzLeben = 0;
                fehlermeldung = lösung;
                spinDisabled = true;
                ratenDisabled = true;
                spielenDisabled = false;

            } else {
                anzLeben = anzLeben - 1;
            }
        }

    }

    //Wort raten
    public void wortRaten() {
        ratenDisabled = true;
        if (wortEingabe.equals(lösung)) {
            fehlermeldung = "Richtig, gewonnen!";
            emptyLösung = lösung;
            guthaben += spinValue;
            spielenDisabled = false;
        } else {
            fehlermeldung = "Falsch!";
            anzLeben -= 1;
        }
    }

    public String highscoreSpeichern() {
        String url = "jdbc:mysql://localhost:3306/gluecksspiel";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url);
            PreparedStatement ps = conn.prepareStatement("INSERT INTO spiel (ID_Spiel, Name, Guthaben) VALUES (?, ?, ?)");
            ps.setString(1, String.valueOf(1));
            ps.setString(2, name);
            ps.setString(3, String.valueOf(guthaben));
            ps.executeUpdate();
            return "erfolg";
        } catch (SQLException ex) {
            System.out.println("Fehler beim Speichern der Daten: " + ex.getMessage());
            return "fehler";
        } catch (ClassNotFoundException ex) {
            return "fehler";
        }
    }

    public void sendEmail() throws URISyntaxException, IOException {
        Desktop desktop;
        if (Desktop.isDesktopSupported()
                && (desktop = Desktop.getDesktop()).isSupported(Desktop.Action.MAIL)) {
            URI mailto = new URI("mailto:O.Much.inf20@stud.bbbaden.ch?subject=Feedback");
            desktop.mail(mailto);
        } else {
            // TODO fallback to some Runtime.exec(..) voodoo?
            throw new RuntimeException("desktop doesn't support mailto; mail is dead anyway ;)");
        }
    }

    public void spielStarten() {

        EntityManager em
                = Persistence.createEntityManagerFactory("com.mycompany_LB_151_war_1.0-SNAPSHOTPU").createEntityManager();
        List< Woerter> woerterList = em.createNamedQuery("Woerter.findAll", Woerter.class).getResultList();

        int randomWord = new Random().nextInt(woerterList.size());
        lösung = woerterList.get(randomWord).getWort();
        spielenDisabled = true;
        spinDisabled = false;
        ratenDisabled = false;
        anzLeben = 3;
        guthaben = 0;
        emptyLösung = "";

        for (int i = 0; i < lösung.length(); i++) {
            emptyLösung = emptyLösung + "_";
        }
    }

    public void kaufKonsonant() {
        if (guthaben >= 1000) {
            String konsonanten = "";
            String alleKonsonanten = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"; // alle Vokale in Groß- und Kleinschreibung

            for (int i = 0; i < lösung.length(); i++) {
                char buchstabe = lösung.charAt(i);
                if (alleKonsonanten.indexOf(buchstabe) != -1) {
                    konsonanten += buchstabe;
                    emptyLösung = emptyLösung.substring(0, lösung.indexOf(buchstabe)) + buchstabe + emptyLösung.substring(lösung.indexOf(buchstabe) + 1);
                }
            }
            guthaben -= 1000;
        } else {
            fehlermeldung = "Guthaben zu klein!";
        }
    }

    public void kaufVokal() {
        if (guthaben >= 1500) {
            String vokale = "";
            String alleVokale = "aeiouAEIOU"; // alle Vokale in Groß- und Kleinschreibung

            for (int i = 0; i < lösung.length(); i++) {
                char buchstabe = lösung.charAt(i);
                if (alleVokale.indexOf(buchstabe) != -1) {
                    vokale += buchstabe;
                    emptyLösung = emptyLösung.substring(0, lösung.indexOf(buchstabe)) + buchstabe + emptyLösung.substring(lösung.indexOf(buchstabe) + 1);
                }
            }
            guthaben -= 1500;
        } else {
            fehlermeldung = "Guthaben zu klein!";
        }

    }
}
